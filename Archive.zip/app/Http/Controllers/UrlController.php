<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Url;
use Illuminate\Support\Str;

class UrlController extends Controller
{
    public function index() {
        $user = auth()->user();
        
        if ($user->hasRole('SuperAdmin')) {
            // SuperAdmin can see all URLs from all companies
            $urls = Url::with(['user', 'client'])->get();
        } elseif ($user->hasRole('Admin')) {
            // Admin can see all URLs created in their own company/client
            $urls = Url::where('client_id', $user->client_id)
                       ->with(['user', 'client'])
                       ->get();
        } else {
            // Member can only see URLs created by themselves
            $urls = Url::where('user_id', $user->id)
                       ->with('client')
                       ->get();
        }
        
        return view('urls.index', compact('urls'));
    }

    public function create() {
        $user = auth()->user();
        if (!$user->hasRole('Admin') && !$user->hasRole('Member')) {
            abort(403, 'Unauthorized');
        }
        return view('urls.create');
    }

    public function store(Request $request) {
        $user = auth()->user();
        if (!$user->hasRole('Admin') && !$user->hasRole('Member')) {
            abort(403, 'Unauthorized');
        }
        $request->validate([
            'original_url' => 'required|url',
        ]);
        $shortCode = Str::random(6);
        $url = Url::create([
            'original_url' => $request->original_url,
            'short_code' => $shortCode,
            'user_id' => $user->id,
            'client_id' => $user->client_id,
        ]);
        return redirect()->route('urls.index')
            ->with('success', 'URL shortened successfully!');
    }
    
    public function redirect($shortCode) {
        $url = Url::where('short_code', $shortCode)->firstOrFail();
        return redirect()->to($url->original_url);
    }
}
