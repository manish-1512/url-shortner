<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Mail\ClientInvitation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class ClientController extends Controller
{
    /**
     * Show the form for inviting a new client.
     */
    public function create()
    {
        return view('clients.invite');
    }

    /**
     * Store a newly invited client.
     */
    public function store(Request $request)
    {
        $inviter = auth()->user();
        
        // Set validation rules based on user role
        $validationRules = [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
        ];
        
        if ($inviter->hasRole('Admin')) {
            $validationRules['role'] = 'required|in:Admin,Member';
        } elseif ($inviter->hasRole('SuperAdmin')) {
            $validationRules['role'] = 'required|in:Admin';
        }
        
        $request->validate($validationRules);

        if (!$inviter->hasRole('SuperAdmin') && !$inviter->hasRole('Admin')) {
            abort(403, 'Unauthorized');
        }

        // Create the client
        $client = Client::create([
            'name' => $request->name,
        ]);

        // Create user with password
        $password = 12345678;
        $user = \App\Models\User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($password),
            'client_id' => $client->id,
            'invited_by' => $inviter->id,
        ]);
        
        // Assign the selected role
        $user->assignRole($request->role);

        // Send invitation email
        try {
            Mail::to($request->email)->send(new ClientInvitation(
                $client->name,
                $inviter->name,
                $request->email,
                $password,
                $request->role
            ));
            
            return redirect()->route('dashboard')
                ->with('success', 'Client invited successfully as ' . $request->role . '. Email: ' . $request->email . ' Password: ' . $password);
        } catch (\Exception $e) {
            // If email fails, still create the client but show a warning
            return redirect()->route('dashboard')
                ->with('success', 'Client created successfully, but invitation email could not be sent. Please try again later.');
        }
    }
} 