<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100">
            <nav class="bg-white border-b border-gray-100">
                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div class="flex justify-between h-16">
                        <div class="flex">
                            <div class="shrink-0 flex items-center">
                                <span class="text-xl font-bold text-gray-800">URL Shortener</span>
                            </div>
                        </div>
                        <div class="flex items-center">
                            <?php if(auth()->guard()->check()): ?>
                                <a href="<?php echo e(route('dashboard')); ?>" class="text-sm text-gray-500 hover:text-gray-700 mr-4">Dashboard</a>
                                <span class="text-gray-700"><?php echo e(Auth::user()->name); ?></span>
                                <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline ml-4">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="text-sm text-gray-500 hover:text-gray-700">Logout</button>
                                </form>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-500 hover:text-gray-700">Login</a>
                                <a href="<?php echo e(route('register')); ?>" class="text-sm text-gray-500 hover:text-gray-700 ml-4">Register</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </nav>

            <main>
                <div class="py-12">
                    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                            <div class="p-6 text-gray-900">
                                <h1 class="text-3xl font-bold mb-4">Welcome to URL Shortener</h1>
                                <p class="text-lg mb-4">Create short, memorable URLs for your long links.</p>
                                <?php if(auth()->guard()->check()): ?>
                                    <a href="<?php echo e(route('dashboard')); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 focus:bg-indigo-700 active:bg-indigo-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                                        Go to Dashboard
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('login')); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 focus:bg-indigo-700 active:bg-indigo-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                                        Get Started
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </body>
</html> <?php /**PATH /Users/imac211/Desktop/url/url-shortener/resources/views/welcome.blade.php ENDPATH**/ ?>