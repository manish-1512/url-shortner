<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100">
            <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- Page Heading -->
            <header class="bg-white shadow">
                <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                    <div class="flex justify-between items-center">
                        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                            Client Details
                        </h2>
                        <div class="flex space-x-4">
                            <a href="<?php echo e(route('clients.edit', $client)); ?>" class="text-sm text-green-600 hover:text-green-700">Edit</a>
                            <a href="<?php echo e(route('dashboard')); ?>" class="text-sm text-gray-500 hover:text-gray-700">Back to Dashboard</a>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Page Content -->
            <main>
                <div class="py-12">
                    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                            <div class="p-6 text-gray-900">
                                <div class="mb-6">
                                    <h3 class="text-lg font-semibold mb-4"><?php echo e($client->name); ?></h3>
                                    
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <h4 class="text-sm font-medium text-gray-500 uppercase tracking-wide mb-2">Client Information</h4>
                                            <dl class="space-y-2">
                                                <div>
                                                    <dt class="text-sm font-medium text-gray-500">Name</dt>
                                                    <dd class="text-sm text-gray-900"><?php echo e($client->name); ?></dd>
                                                </div>
                                                <div>
                                                    <dt class="text-sm font-medium text-gray-500">Created</dt>
                                                    <dd class="text-sm text-gray-900"><?php echo e($client->created_at->format('F d, Y \a\t g:i A')); ?></dd>
                                                </div>
                                                <div>
                                                    <dt class="text-sm font-medium text-gray-500">Last Updated</dt>
                                                    <dd class="text-sm text-gray-900"><?php echo e($client->updated_at->format('F d, Y \a\t g:i A')); ?></dd>
                                                </div>
                                            </dl>
                                        </div>
                                        
                                        <div>
                                            <h4 class="text-sm font-medium text-gray-500 uppercase tracking-wide mb-2">Users</h4>
                                            <?php if($client->users->count() > 0): ?>
                                                <ul class="space-y-2">
                                                    <?php $__currentLoopData = $client->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li class="text-sm text-gray-900"><?php echo e($user->name); ?> (<?php echo e($user->email); ?>)</li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            <?php else: ?>
                                                <p class="text-sm text-gray-500">No users associated with this client.</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="flex justify-between items-center pt-6 border-t border-gray-200">
                                    <form method="POST" action="<?php echo e(route('clients.destroy', $client)); ?>" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" 
                                                class="text-red-600 hover:text-red-900 text-sm"
                                                onclick="return confirm('Are you sure you want to delete this client? This action cannot be undone.')">
                                            Delete Client
                                        </button>
                                    </form>
                                    
                                    <a href="<?php echo e(route('clients.edit', $client)); ?>" 
                                       class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 focus:bg-indigo-700 active:bg-indigo-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                                        Edit Client
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </body>
</html> <?php /**PATH /Users/imac211/Desktop/url/url-shortener/resources/views/clients/show.blade.php ENDPATH**/ ?>