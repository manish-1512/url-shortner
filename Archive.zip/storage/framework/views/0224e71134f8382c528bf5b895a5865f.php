<?php $__env->startSection('content'); ?>
<div class="container">
  <h2>SuperAdmin Dashboard</h2>

  <div class="mb-4">
    <a href="<?php echo e(route('clients.create')); ?>" class="btn btn-primary me-2">Invite Admin</a>
    <a href="<?php echo e(route('urls.index')); ?>" class="btn btn-info">View All URLs</a>
  </div>

  <!-- Admins Section -->
  <div class="card mb-4">
    <div class="card-header">
      <h5 class="mb-0">All Admins (<?php echo e($admins->count()); ?>)</h5>
    </div>
    <div class="card-body">
      <?php if($admins->count() > 0): ?>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Client</th>
              <th>Created</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($admin->name); ?></td>
                <td><?php echo e($admin->email); ?></td>
                <td><?php echo e($admin->client->name ?? 'N/A'); ?></td>
                <td><?php echo e($admin->created_at->format('M d, Y')); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      <?php else: ?>
        <p class="text-muted mb-0">No admins found.</p>
      <?php endif; ?>
    </div>
  </div>

  <!-- URLs Section -->
  <div class="card">
    <div class="card-header">
      <h5 class="mb-0">All URLs (<?php echo e($urls->count()); ?>)</h5>
    </div>
    <div class="card-body">
      <?php if($urls->count() > 0): ?>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Original URL</th>
              <th>Short URL</th>
              <th>Created By</th>
              <th>Client</th>
              <th>Created</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <div class="text-truncate" style="max-width: 200px;" title="<?php echo e($url->original_url); ?>">
                    <?php echo e($url->original_url); ?>

                  </div>
                </td>
                <td>
                  <a href="<?php echo e(route('url.redirect', $url->short_code)); ?>" 
                     target="_blank"
                     class="text-decoration-none">
                    <?php echo e(url('/')); ?>/<?php echo e($url->short_code); ?>

                  </a>
                </td>
                <td><?php echo e($url->user->name ?? 'N/A'); ?></td>
                <td><?php echo e($url->client->name ?? 'N/A'); ?></td>
                <td><?php echo e($url->created_at->format('M d, Y')); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      <?php else: ?>
        <p class="text-muted mb-0">No URLs found.</p>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/imac211/Desktop/url/url-shortener/resources/views/dashboard/superadmin.blade.php ENDPATH**/ ?>