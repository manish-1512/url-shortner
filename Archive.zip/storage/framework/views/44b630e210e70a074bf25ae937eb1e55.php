<?php $__env->startSection('content'); ?>
<div class="container">
  <h2>Admin Dashboard</h2>

  <div class="mb-4">
    <a href="<?php echo e(route('clients.create')); ?>" class="btn btn-primary me-2">Invite Client</a>
    <a href="<?php echo e(route('urls.index')); ?>" class="btn btn-info">View All URLs</a>
  </div>

  <?php if($client): ?>
    <h4>Client: <?php echo e($client->name); ?></h4>
  <?php endif; ?>

  <!-- Invited Members Section -->
  <div class="card mb-4">
    <div class="card-header">
      <h5 class="mb-0">Members I Invited (<?php echo e($invitedMembers->count()); ?>)</h5>
    </div>
    <div class="card-body">
      <?php if($invitedMembers->count() > 0): ?>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Created</th>
              <th>URLs Created</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $invitedMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($member->name); ?></td>
                <td><?php echo e($member->email); ?></td>
                <td><?php echo e($member->created_at->format('M d, Y')); ?></td>
                <td><?php echo e($clientUrls->where('user_id', $member->id)->count()); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      <?php else: ?>
        <p class="text-muted mb-0">You haven't invited any members yet. Use the "Invite Client" button to invite new team members.</p>
      <?php endif; ?>
    </div>
  </div>

  <!-- URLs Section -->
  <div class="card">
    <div class="card-header">
      <h5 class="mb-0">URLs Created by Me and My Invited Members (<?php echo e($clientUrls->count()); ?>)</h5>
    </div>
    <div class="card-body">
      <?php if($clientUrls->count() > 0): ?>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Original URL</th>
              <th>Short URL</th>
              <th>Created By</th>
              <th>Created</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $clientUrls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <div class="text-truncate" style="max-width: 200px;" title="<?php echo e($url->original_url); ?>">
                    <?php echo e($url->original_url); ?>

                  </div>
                </td>
                <td>
                  <a href="<?php echo e(route('url.redirect', $url->short_code)); ?>" 
                     target="_blank"
                     class="text-decoration-none">
                    <?php echo e(url('/')); ?>/<?php echo e($url->short_code); ?>

                  </a>
                </td>
                <td>
                  <?php if($url->user_id == auth()->id()): ?>
                    <span class="badge bg-primary">Me</span>
                  <?php else: ?>
                    <?php echo e($url->user->name ?? 'N/A'); ?>

                  <?php endif; ?>
                </td>
                <td><?php echo e($url->created_at->format('M d, Y')); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      <?php else: ?>
        <p class="text-muted mb-0">No URLs found. Start creating URLs to see them here.</p>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/imac211/Desktop/url/url-shortener/resources/views/dashboard/admin.blade.php ENDPATH**/ ?>