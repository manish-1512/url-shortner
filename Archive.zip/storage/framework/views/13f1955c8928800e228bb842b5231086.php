<?php $__env->startSection('content'); ?>
<div class="container">
  <h2>Member Dashboard</h2>

  <div class="mb-4">
    <a href="<?php echo e(route('urls.create')); ?>" class="btn btn-success me-2">Generate Short URL</a>
    <a href="<?php echo e(route('urls.index')); ?>" class="btn btn-info">View All URLs</a>
  </div>

  <h4>My URLs</h4>
  <?php if($userUrls->count() > 0): ?>
    <table class="table table-bordered">
      <tr><th>Short Code</th><th>Original URL</th><th>Created</th></tr>
      <?php $__currentLoopData = $userUrls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><a href="/<?php echo e($url->short_code); ?>"><?php echo e($url->short_code); ?></a></td>
          <td><?php echo e($url->original_url); ?></td>
          <td><?php echo e($url->created_at->format('M d, Y')); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  <?php else: ?>
    <p class="text-muted">No URLs found. Create your first short URL using the button above!</p>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/imac211/Desktop/url/url-shortener/resources/views/dashboard/member.blade.php ENDPATH**/ ?>