<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2>URLs</h2>
    <div>
      <?php if(auth()->user()->hasRole('Admin') || auth()->user()->hasRole('Member')): ?>
        <a href="<?php echo e(route('urls.create')); ?>" class="btn btn-primary me-2">Create URL</a>
      <?php endif; ?>
      <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary">Back to Dashboard</a>
    </div>
  </div>

  <?php if(session('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>

  <div class="card">
    <div class="card-header">
      <h4 class="mb-0">Shortened URLs</h4>
    </div>
    <div class="card-body">
      <?php if($urls->count() > 0): ?>
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>Original URL</th>
                <th>Short URL</th>
                <th>Created By</th>
                <?php if(auth()->user()->hasRole('SuperAdmin')): ?>
                  <th>Client</th>
                <?php endif; ?>
                <th>Created</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                    <div class="text-truncate" style="max-width: 200px;" title="<?php echo e($url->original_url); ?>">
                      <?php echo e($url->original_url); ?>

                    </div>
                  </td>
                  <td>
                    <a href="<?php echo e(route('url.redirect', $url->short_code)); ?>" 
                       target="_blank"
                       class="text-decoration-none">
                      <?php echo e(url('/')); ?>/<?php echo e($url->short_code); ?>

                    </a>
                  </td>
                  <td><?php echo e($url->user->name ?? 'N/A'); ?></td>
                  <?php if(auth()->user()->hasRole('SuperAdmin')): ?>
                    <td><?php echo e($url->user->client->name ?? 'N/A'); ?></td>
                  <?php endif; ?>
                  <td><?php echo e($url->created_at->format('M d, Y')); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <div class="text-center py-4">
          <p class="text-muted mb-3">No URLs found.</p>
          <?php if(auth()->user()->hasRole('Admin') || auth()->user()->hasRole('Member')): ?>
            <a href="<?php echo e(route('urls.create')); ?>" class="btn btn-primary">Create Your First URL</a>
          <?php endif; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/imac211/Desktop/url/url-shortener/resources/views/urls/index.blade.php ENDPATH**/ ?>