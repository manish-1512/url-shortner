@extends('layouts.app')
@section('content')
<div class="container">
  <h2>Member Dashboard</h2>

  <div class="mb-4">
    <a href="{{ route('urls.create') }}" class="btn btn-success me-2">Generate Short URL</a>
    <a href="{{ route('urls.index') }}" class="btn btn-info">View All URLs</a>
  </div>

  <h4>My URLs</h4>
  @if($userUrls->count() > 0)
    <table class="table table-bordered">
      <tr><th>Short Code</th><th>Original URL</th><th>Created</th></tr>
      @foreach($userUrls as $url)
        <tr>
          <td><a href="/{{ $url->short_code }}">{{ $url->short_code }}</a></td>
          <td>{{ $url->original_url }}</td>
          <td>{{ $url->created_at->format('M d, Y') }}</td>
        </tr>
      @endforeach
    </table>
  @else
    <p class="text-muted">No URLs found. Create your first short URL using the button above!</p>
  @endif
</div>
@endsection