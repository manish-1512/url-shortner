@extends('layouts.app')
@section('content')
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h4 class="mb-0">Create Short URL</h4>
        </div>
        <div class="card-body">
          <form method="POST" action="{{ route('urls.store') }}">
            @csrf
            
            <div class="mb-3">
              <label for="original_url" class="form-label">Original URL</label>
              <input type="url" 
                     name="original_url" 
                     id="original_url" 
                     value="{{ old('original_url') }}"
                     placeholder="https://example.com/very-long-url"
                     class="form-control"
                     required>
              <div class="form-text">Enter the long URL you want to shorten.</div>
              @error('original_url')
                <div class="text-danger">{{ $message }}</div>
              @enderror
            </div>

            <div class="d-flex justify-content-between">
              <a href="{{ route('dashboard') }}" class="btn btn-secondary">Cancel</a>
              <button type="submit" class="btn btn-success">Create Short URL</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection 