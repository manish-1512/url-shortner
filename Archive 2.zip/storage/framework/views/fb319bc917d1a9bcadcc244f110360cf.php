<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h4 class="mb-0">Invite Client</h4>
        </div>
        <div class="card-body">
          <form method="POST" action="<?php echo e(route('clients.store')); ?>">
            <?php echo csrf_field(); ?>
            
            <div class="mb-3">
              <label for="name" class="form-label">Client Name</label>
              <input type="text" 
                     name="name" 
                     id="name" 
                     value="<?php echo e(old('name')); ?>"
                     class="form-control"
                     required>
              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">
              <label for="email" class="form-label">Client Email</label>
              <input type="email" 
                     name="email" 
                     id="email" 
                     value="<?php echo e(old('email')); ?>"
                     class="form-control"
                     required>
              <div class="form-text">An invitation will be sent to this email address.</div>
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <?php if(auth()->user()->hasRole('Admin')): ?>
              <div class="mb-3">
                <label for="role" class="form-label">User Role</label>
                <select name="role" 
                        id="role" 
                        class="form-control"
                        required>
                  <option value="">Select a role</option>
                  <option value="Admin" <?php echo e(old('role') == 'Admin' ? 'selected' : ''); ?>>Admin</option>
                  <option value="Member" <?php echo e(old('role') == 'Member' ? 'selected' : ''); ?>>Member</option>
                </select>
                <div class="form-text">Choose the role for the invited user.</div>
                <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            <?php endif; ?>

            <?php if(auth()->user()->hasRole('SuperAdmin')): ?>
              <input type="hidden" name="role" value="Admin">
            <?php endif; ?>

            <div class="d-flex justify-content-between">
              <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary">Cancel</a>
              <button type="submit" class="btn btn-primary">Send Invitation</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/imac211/Desktop/url/url-shortener/resources/views/clients/invite.blade.php ENDPATH**/ ?>