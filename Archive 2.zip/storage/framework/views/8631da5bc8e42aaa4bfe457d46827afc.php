<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Client Invitation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background-color: #4f46e5;
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 8px 8px 0 0;
        }
        .content {
            background-color: #f9fafb;
            padding: 30px;
            border-radius: 0 0 8px 8px;
        }
        .button {
            display: inline-block;
            background-color: #4f46e5;
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 6px;
            margin: 20px 0;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            color: #6b7280;
            font-size: 14px;
        }
        .role-badge {
            display: inline-block;
            background-color: #10b981;
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>URL Shortener</h1>
    </div>
    
    <div class="content">
        <h2>You've been invited!</h2>
        
        <p>Hello,</p>
        
        <p><?php echo e($inviterName); ?> has invited you to join <strong><?php echo e($clientName); ?></strong> on our URL Shortener platform.</p>
        
        <p>You have been assigned the role of: <span class="role-badge"><?php echo e($role); ?></span></p>
        
        <p>This platform allows you to create and manage short URLs for your organization's links.</p>
        
        <p>To get started, please click the button below to create your account:</p>
        
        <div style="text-align: center;">
            <a href="<?php echo e(url('/register')); ?>" class="button">Create Account</a>
        </div>
        
        <p>If you have any questions, please don't hesitate to contact us.</p>
        
        <p><strong>Login Email:</strong> <?php echo e($email); ?></p>
        <p><strong>Temporary Password:</strong> <?php echo e($password); ?></p>
        <p>You can log in and change your password after your first login.</p>
        
        <p>Best regards,<br>
        The URL Shortener Team</p>
    </div>
    
    <div class="footer">
        <p>This invitation was sent from the URL Shortener platform.</p>
        <p>If you didn't expect this invitation, you can safely ignore this email.</p>
    </div>
</body>
</html> <?php /**PATH /Users/imac211/Desktop/url/url-shortener/resources/views/emails/client-invitation.blade.php ENDPATH**/ ?>