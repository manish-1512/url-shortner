@extends('layouts.app')
@section('content')
<div class="container">
  <h2>Admin Dashboard</h2>

  <div class="mb-4">
    <a href="{{ route('clients.create') }}" class="btn btn-primary me-2">Invite Client</a>
    <a href="{{ route('urls.index') }}" class="btn btn-info">View All URLs</a>
  </div>

  @if($client)
    <h4>Client: {{ $client->name }}</h4>
  @endif

  <!-- Invited Members Section -->
  <div class="card mb-4">
    <div class="card-header">
      <h5 class="mb-0">Members I Invited ({{ $invitedMembers->count() }})</h5>
    </div>
    <div class="card-body">
      @if($invitedMembers->count() > 0)
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Created</th>
              <th>URLs Created</th>
            </tr>
          </thead>
          <tbody>
            @foreach($invitedMembers as $member)
              <tr>
                <td>{{ $member->name }}</td>
                <td>{{ $member->email }}</td>
                <td>{{ $member->created_at->format('M d, Y') }}</td>
                <td>{{ $clientUrls->where('user_id', $member->id)->count() }}</td>
              </tr>
            @endforeach
          </tbody>
        </table>
      @else
        <p class="text-muted mb-0">You haven't invited any members yet. Use the "Invite Client" button to invite new team members.</p>
      @endif
    </div>
  </div>

  <!-- URLs Section -->
  <div class="card">
    <div class="card-header">
      <h5 class="mb-0">URLs Created by Me and My Invited Members ({{ $clientUrls->count() }})</h5>
    </div>
    <div class="card-body">
      @if($clientUrls->count() > 0)
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Original URL</th>
              <th>Short URL</th>
              <th>Created By</th>
              <th>Created</th>
            </tr>
          </thead>
          <tbody>
            @foreach($clientUrls as $url)
              <tr>
                <td>
                  <div class="text-truncate" style="max-width: 200px;" title="{{ $url->original_url }}">
                    {{ $url->original_url }}
                  </div>
                </td>
                <td>
                  <a href="{{ route('url.redirect', $url->short_code) }}" 
                     target="_blank"
                     class="text-decoration-none">
                    {{ url('/') }}/{{ $url->short_code }}
                  </a>
                </td>
                <td>
                  @if($url->user_id == auth()->id())
                    <span class="badge bg-primary">Me</span>
                  @else
                    {{ $url->user->name ?? 'N/A' }}
                  @endif
                </td>
                <td>{{ $url->created_at->format('M d, Y') }}</td>
              </tr>
            @endforeach
          </tbody>
        </table>
      @else
        <p class="text-muted mb-0">No URLs found. Start creating URLs to see them here.</p>
      @endif
    </div>
  </div>
</div>
@endsection