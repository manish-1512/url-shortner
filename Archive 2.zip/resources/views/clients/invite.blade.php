@extends('layouts.app')
@section('content')
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h4 class="mb-0">Invite Client</h4>
        </div>
        <div class="card-body">
          <form method="POST" action="{{ route('clients.store') }}">
            @csrf
            
            <div class="mb-3">
              <label for="name" class="form-label">Client Name</label>
              <input type="text" 
                     name="name" 
                     id="name" 
                     value="{{ old('name') }}"
                     class="form-control"
                     required>
              @error('name')
                <div class="text-danger">{{ $message }}</div>
              @enderror
            </div>

            <div class="mb-3">
              <label for="email" class="form-label">Client Email</label>
              <input type="email" 
                     name="email" 
                     id="email" 
                     value="{{ old('email') }}"
                     class="form-control"
                     required>
              <div class="form-text">An invitation will be sent to this email address.</div>
              @error('email')
                <div class="text-danger">{{ $message }}</div>
              @enderror
            </div>

            @if(auth()->user()->hasRole('Admin'))
              <div class="mb-3">
                <label for="role" class="form-label">User Role</label>
                <select name="role" 
                        id="role" 
                        class="form-control"
                        required>
                  <option value="">Select a role</option>
                  <option value="Admin" {{ old('role') == 'Admin' ? 'selected' : '' }}>Admin</option>
                  <option value="Member" {{ old('role') == 'Member' ? 'selected' : '' }}>Member</option>
                </select>
                <div class="form-text">Choose the role for the invited user.</div>
                @error('role')
                  <div class="text-danger">{{ $message }}</div>
                @enderror
              </div>
            @endif

            @if(auth()->user()->hasRole('SuperAdmin'))
              <input type="hidden" name="role" value="Admin">
            @endif

            <div class="d-flex justify-content-between">
              <a href="{{ route('dashboard') }}" class="btn btn-secondary">Cancel</a>
              <button type="submit" class="btn btn-primary">Send Invitation</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection 