@extends('layouts.app')
@section('content')
<div class="container">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2>URLs</h2>
    <div>
      @if(auth()->user()->hasRole('Admin') || auth()->user()->hasRole('Member'))
        <a href="{{ route('urls.create') }}" class="btn btn-primary me-2">Create URL</a>
      @endif
      <a href="{{ route('dashboard') }}" class="btn btn-secondary">Back to Dashboard</a>
    </div>
  </div>

  @if(session('success'))
    <div class="alert alert-success">
      {{ session('success') }}
    </div>
  @endif

  <div class="card">
    <div class="card-header">
      <h4 class="mb-0">Shortened URLs</h4>
    </div>
    <div class="card-body">
      @if($urls->count() > 0)
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>Original URL</th>
                <th>Short URL</th>
                <th>Created By</th>
                @if(auth()->user()->hasRole('SuperAdmin'))
                  <th>Client</th>
                @endif
                <th>Created</th>
              </tr>
            </thead>
            <tbody>
              @foreach($urls as $url)
                <tr>
                  <td>
                    <div class="text-truncate" style="max-width: 200px;" title="{{ $url->original_url }}">
                      {{ $url->original_url }}
                    </div>
                  </td>
                  <td>
                    <a href="{{ route('url.redirect', $url->short_code) }}" 
                       target="_blank"
                       class="text-decoration-none">
                      {{ url('/') }}/{{ $url->short_code }}
                    </a>
                  </td>
                  <td>{{ $url->user->name ?? 'N/A' }}</td>
                  @if(auth()->user()->hasRole('SuperAdmin'))
                    <td>{{ $url->user->client->name ?? 'N/A' }}</td>
                  @endif
                  <td>{{ $url->created_at->format('M d, Y') }}</td>
                </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      @else
        <div class="text-center py-4">
          <p class="text-muted mb-3">No URLs found.</p>
          @if(auth()->user()->hasRole('Admin') || auth()->user()->hasRole('Member'))
            <a href="{{ route('urls.create') }}" class="btn btn-primary">Create Your First URL</a>
          @endif
        </div>
      @endif
    </div>
  </div>
</div>
@endsection 