# URL Shortener with Role-Based Access Control

A Laravel-based URL shortening application with multi-role user management system. This project allows SuperAdmins, Admins, and Members to manage URLs with different levels of access and permissions.

## 🚀 Features

### User Roles & Permissions
- **SuperAdmin**: Can invite Admins, view all admins across all companies, and see all URLs
- **Admin**: Can invite Members and other Admins to their company, manage team URLs
- **Member**: Can create and manage their own URLs

### Core Functionality
- ✅ URL shortening with custom short codes
- ✅ Role-based dashboard views
- ✅ User invitation system with email notifications
- ✅ Client/Company management
- ✅ Clean Bootstrap UI
- ✅ Responsive design

## 📋 Prerequisites

Before you begin, ensure you have the following installed:
- **PHP 8.1+**
- **Composer**
- **MySQL/PostgreSQL**
- **Node.js & NPM** (for frontend assets)

## 🛠️ Installation & Setup

### 1. Clone the Repository
```bash
git clone <repository-url>
cd url-shortener
```

### 2. Install Dependencies
```bash
composer install
npm install
```

### 3. Environment Configuration
```bash
cp .env.example .env
```

Edit the `.env` file with your database and mail settings:
```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=url_shortener
DB_USERNAME=your_username
DB_PASSWORD=your_password

MAIL_MAILER=smtp
MAIL_HOST=smtp.mailtrap.io
MAIL_PORT=2525
MAIL_USERNAME=your_mail_username
MAIL_PASSWORD=your_mail_password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS="noreply@example.com"
MAIL_FROM_NAME="${APP_NAME}"
```

### 4. Generate Application Key
```bash
php artisan key:generate
```

### 5. Run Database Migrations
```bash
php artisan migrate
```

### 6. Seed the Database (Optional)
```bash
php artisan db:seed
```

### 7. Build Frontend Assets
```bash
npm run build
```

### 8. Set Storage Permissions
```bash
php artisan storage:link
chmod -R 775 storage bootstrap/cache
```

## 🚀 Running the Application

### Start the Development Server
```bash
php artisan serve
```

The application will be available at `http://localhost:8000`

### Queue Worker (for email processing)
If you want email invitations to work properly, run:
```bash
php artisan queue:work
```

## 👥 User Management

### Creating Initial SuperAdmin
Since registration is disabled, you'll need to create a SuperAdmin manually:

1. Create a user in the database:
```sql
INSERT INTO users (name, email, password, created_at, updated_at) 
VALUES ('SuperAdmin', 'admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', NOW(), NOW());
```

2. Assign SuperAdmin role:
```sql
INSERT INTO model_has_roles (role_id, model_type, model_id) 
VALUES (1, 'App\\Models\\User', 1);
```

### Default Login Credentials
- **Email**: admin@example.com
- **Password**: password

## 📁 Project Structure

```
url-shortener/
├── app/
│   ├── Http/Controllers/
│   │   ├── Auth/           # Authentication controllers
│   │   ├── ClientController.php
│   │   ├── DashboardController.php
│   │   └── UrlController.php
│   ├── Models/
│   │   ├── Client.php
│   │   ├── Url.php
│   │   └── User.php
│   └── Mail/
│       └── ClientInvitation.php
├── database/
│   ├── migrations/         # Database migrations
│   └── seeders/           # Database seeders
├── resources/
│   └── views/
│       ├── auth/          # Authentication views
│       ├── dashboard/     # Role-specific dashboards
│       ├── urls/          # URL management views
│       └── layouts/       # Layout templates
└── routes/
    ├── web.php           # Web routes
    └── auth.php          # Authentication routes
```

## 🔐 Role-Based Access

### SuperAdmin Dashboard
- View all admins across all companies
- View all URLs from all companies
- Invite new admins

### Admin Dashboard
- View members they've invited
- View URLs created by themselves and their invited members
- Invite new members or admins

### Member Dashboard
- View and manage their own URLs
- Create new shortened URLs

## 🧪 Testing

### Running Tests
```bash
php artisan test
```

### Manual Testing Scenarios
1. **SuperAdmin Flow**:
   - Login as SuperAdmin
   - Invite a new Admin
   - View all admins and URLs

2. **Admin Flow**:
   - Login as Admin
   - Invite Members
   - Create URLs
   - View team URLs

3. **Member Flow**:
   - Login as Member
   - Create URLs
   - View own URLs

## 📧 Email Configuration

The application sends invitation emails when new users are invited. Make sure to configure your email settings in the `.env` file.

For testing, you can use:
- **Mailtrap** (recommended for development)
- **Gmail SMTP**
- **SendGrid**

## 🔧 Troubleshooting

### Common Issues

1. **"Vite manifest not found"**
   ```bash
   npm run build
   ```

2. **Database connection issues**
   - Check your `.env` file database settings
   - Ensure MySQL/PostgreSQL is running

3. **Permission errors**
   ```bash
   chmod -R 775 storage bootstrap/cache
   ```

4. **Email not sending**
   - Check mail configuration in `.env`
   - Run queue worker: `php artisan queue:work`

## 📝 API Endpoints

### Public Routes
- `GET /` - Redirects to login
- `GET /{shortCode}` - Redirects to original URL

### Protected Routes
- `GET /dashboard` - Role-based dashboard
- `GET /urls` - URL listing
- `POST /urls` - Create new URL
- `GET /clients/create` - Invite form
- `POST /clients` - Send invitation

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).

## 🆘 Support

If you encounter any issues or have questions:
1. Check the troubleshooting section above
2. Review the Laravel documentation
3. Create an issue in the repository

---

**Happy URL Shortening! 🎉**
