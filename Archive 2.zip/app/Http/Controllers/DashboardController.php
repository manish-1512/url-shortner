<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Client;
use App\Models\User;
use App\Models\Url;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        
        if ($user->hasRole('SuperAdmin')) {
            // SuperAdmin sees all admins and all URLs
            $admins = User::whereHas('roles', function($query) {
                $query->where('name', 'Admin');
            })->with('client')->get();
            
            $urls = Url::with(['user', 'client'])->get();
            return view('dashboard.superadmin', compact('admins', 'urls'));
            
        } elseif ($user->hasRole('Admin')) {
            // Admin sees members they invited and URLs from those members
            $invitedMembers = User::where('invited_by', $user->id)
                                 ->whereHas('roles', function($query) {
                                     $query->where('name', 'Member');
                                 })
                                 ->get();
            
            // Get URLs created by the admin and their invited members
            $invitedMemberIds = $invitedMembers->pluck('id')->toArray();
            $invitedMemberIds[] = $user->id; // Include admin's own URLs
            
            $clientUrls = Url::whereIn('user_id', $invitedMemberIds)
                            ->with(['user', 'client'])
                            ->get();
            
            $client = Client::find($user->client_id);
            return view('dashboard.admin', compact('invitedMembers', 'clientUrls', 'client'));
            
        } else {
            // Member sees only their own URLs
            $userUrls = Url::where('user_id', $user->id)->get();
            return view('dashboard.member', compact('userUrls'));
        }
    }
} 